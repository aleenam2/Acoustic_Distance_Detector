#ifndef PSTATS_H
#define PSTATS_H

void pstats_init(void);
void pstats_report(void);
 
#endif
