package com.ece420.lab6;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ActivityInfo;
import android.Manifest;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Receiver extends AppCompatActivity{
    private Button startRecButton;
    private Button stopRecButton;

//    private TextView textStatus; // TextView to show the status

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content to a layout that contains your button. You need to create this layout file.
        setContentView(R.layout.receiver);

        startRecButton = (Button) findViewById(R.id.startRecording);
        stopRecButton = (Button) findViewById(R.id.stopRecording);

        // Set up any onClickListener for sendChirp button if needed.

        startRecButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Receiver.this, "Recording started", Toast.LENGTH_SHORT).show();
            }
        });

        stopRecButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Receiver.this, "Recording stopped", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
