package com.ece420.lab6;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ActivityInfo;
import android.Manifest;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Sender extends AppCompatActivity{

    private Button sendChirp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content to a layout that contains your button. You need to create this layout file.
        setContentView(R.layout.sender);

        sendChirp = (Button) findViewById(R.id.sendChirpButton);
        // Set up any onClickListener for sendChirp button if needed.
    }
}
